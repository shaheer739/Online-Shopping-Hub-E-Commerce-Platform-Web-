<?php
 $server = 'localhost';
 $user = 'root';
 $pass = '';
 $db = 'ecommercelogin';
 $mysqli = new mysqli($server, $user, $pass, $db);
?>