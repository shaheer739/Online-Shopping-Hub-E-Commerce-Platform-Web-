<?php
include 'header.html';
?>

<!DOCTYPE html>
<html>
<head>
<title>history</title>
<link rel="stylesheet" href="history.css">
</head>
<body>
<div>
<div class="form">  
<?php
include 'ecommerce.php';
$sql = "SELECT * FROM `userloginhistory`";
$result = mysqli_query($mysqli,$sql);
$num = mysqli_num_rows($result);
$cnt = 1;
$sql1 = "SELECT * FROM `userhistory`";
$result1 = mysqli_query($mysqli,$sql1);
$sum = '0';

while($ui = mysqli_fetch_row($result)){
if($num != $cnt){
    $cnt++;
}
else
{
    $cnt = 1;
    break;
}}

while($uh = mysqli_fetch_row($result1)){
    if($ui[1] == $uh[1]){
        echo '<p style="font-size:23px ;">' . $uh[2] . "   [" .  $uh[3] . "]" . '</p>';
        $sum = $sum + $uh[3];
    }    
}
echo '<p style="font-size:30px ;">' . '<b>' . "Total Spendings:  " . $sum . '</b>'.'</p>';
?>
</div><div>
</body></html>

<?php
include 'footer.html';
?>