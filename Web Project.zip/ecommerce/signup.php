<!DOCTYPE html>
<html lang="en">
<head>
    <title>login</title>
    <link rel="stylesheet" href="signup.css">
</head>
<body>
    
 <form action ="signup.php" method="post">
    <div>
        <br><br> <br><br>
    <div class="form">
        <br>
        Name:<br>
        <input type="name" name="fname"><br><br>
        Email Address:<br>
        <input type="email" name="email"><br><br>
        Password:<br>
        <input type="password" name="password"><br><br>
        Date of Birth:<br>
        <input type="date" name="dob"><br><br>
        Gender:<br>
        <select name="gender">
            <option></option>
            <option name="M" >Male</option>
            <option name="F">Female</option>
        </select><br><br>
        Country:<br>
        <input type="text" name="country"><br><br>
        City:<br>
        <input type="name" name="city"><br><br>
        Phone Number:<br>
        <input type="text" name="pnum"><br><br>
        <button name="register">Register</button>
        <button name="login">Login</button>
    </div>
    <br><br>
    </div>
 </form>
</body>
</html>

<?php
include 'ecommerce.php';
 if (isset($_POST['register'])){
    $gender = $_POST['gender'];
    $fname = $_POST['fname'];
    $email = $_POST['email'];
    $pass = $_POST['password'];
    $dob = $_POST['dob'];
    $country = $_POST['country'];
    $city = $_POST['city'];
    $pnum = $_POST['pnum'];

    $flag = false;
    $sql = "SELECT * FROM `userdetails`";
    $result = mysqli_query($mysqli,$sql);
    while($ud = mysqli_fetch_row($result)){
        if(($email == $ud[2])){
            $flag = true;
            echo ("<script LANGUAGE='JavaScript'>
            window.alert('Email Already Taken');
            window.location.href='signup.php';</script>");
            break;
        }
    }    

    if ($flag == false){
    $insert_query = "INSERT INTO `userdetails` (`Name`, `Email Address`, `Password`, `Date Of Birth`, `Gender`, `Country`, `City`, `Phone Number`) VALUES ('$fname', '$email', '$pass', '$dob','$gender','$country', '$city', '$pnum')";
    $insert_result= mysqli_query($mysqli, $insert_query);
    echo ("<script LANGUAGE='JavaScript'>
    window.alert('Account Successfully Created');
    window.location.href='login.php';
    </script>");
    }
}

    if (isset($_POST['login'])){
        header("Location:login.php");
    }
?>
