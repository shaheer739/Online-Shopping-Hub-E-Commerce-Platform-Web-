<!DOCTYPE html>
<html lang="en">
<head>
    <title>CV</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    
 <form action ="login.php" method="post">
    <div>
        <br><br><br><br><br><br>
    <div class="form">
        <br>
        Your Email:
        <br>
        <input type="text" name='email'><br><br>
        Your Password:
        <br>
        <input type="password" name='password'><br><br>
        <button name="login">Login</button>
        <button name="signup">Sign Up</button>
    </div>
    <br><br>
    </div>
 </form>
</body>
</html>


<?php
    if(isset($_POST['login'])){
    include 'ecommerce.php';
    $sql = "SELECT * FROM `userdetails`";
    $result = mysqli_query($mysqli,$sql);
    $email = $_POST["email"];
    $password = $_POST["password"];

  while($ud = mysqli_fetch_row($result)){
    if(($email == $ud[2]) && ($password == $ud[3])){
    $logindate = date('d F Y, h:i:s A');
    $insert_query = "INSERT INTO `userloginhistory` (`User_ID`, `Login(Time)`) VALUES ('$ud[0]', '$logindate')";
    $insert_result= mysqli_query($mysqli, $insert_query);
        echo ("<script LANGUAGE='JavaScript'>
        window.alert('Login Successful');
        window.location.href='index.html';
        </script>");

    }}
    echo ("<script LANGUAGE='JavaScript'>
        window.alert('Login Failed');
        </script>");
}

if (isset($_POST['signup'])){
    header("Location:signup.php");
}
?>
