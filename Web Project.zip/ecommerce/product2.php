<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navy Blue Solid Sweatshirt</title>
    <link rel="stylesheet" href="product.css">
    <script src="js\jQuery3.4.1.js"></script> 
    <script> 
    $(function(){
      $("#includedContent1").load("header.html");
      $("#includedContent2").load("footer.html");
    });
    </script> 
</head>
<body>
    <header>
        <div id="includedContent1"></div>
    </header>

    <form action="product2.php" method="post"><br>
    <div>
    <div id="y">
        <img id="x" src="img\s6.png">
    <div id="z">
        <h1>Women Black Solid Lightweight Leather Jackett</h1>
        <p id="z1"><b>BARESKIN</b></p>
        <p id="z2"><b>Rs 9999</b></p>
        <p id="z3"><b>Description</b></p>
        <p id="z4"><b>Black Solid Leather Jacket, Has A Spread Collar, 3 Pockets, Zip Closure, Long Sleeves, Straight Hem, Polyester Lining</b></p>
        <br>
        <button id="item"  name='buy'>Buy</button>
    </div>   
    </div>
    </div>
    <br>
    </form>

    <footer>
        <div id="includedContent2"></div>
    </footer>
</body>
</html>

<?php
if (isset($_POST['buy'])){
include 'ecommerce.php';
 $name = 'Women Black Solid Lightweight Leather Jackett';
 $p = '9999';
 $date = date('d F Y, h:i:s A');
 $sql = "SELECT * FROM `userloginhistory`";
 $result = mysqli_query($mysqli,$sql);
 $num = mysqli_num_rows($result);
 $cnt = 1;
 
 while($ui = mysqli_fetch_row($result)){
 if($num != $cnt){
     $cnt++;
 }
 else
 {
     $cnt = 1;
     break;
 }}
    $insert_query = "INSERT INTO `userhistory` (`User_ID`, `Item Purchased`, `Price`,`Date`) VALUES ('$ui[1]', '$name', '$p', '$date')";
    $insert_result= mysqli_query($mysqli, $insert_query);
    echo ("<script LANGUAGE='JavaScript'>
    window.alert('Item Successfully Bought');
    window.location.href='index.html';
    </script>");
}
?>